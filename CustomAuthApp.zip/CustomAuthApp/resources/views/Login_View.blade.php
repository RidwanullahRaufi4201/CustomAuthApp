<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href={{asset('assets/css/bootstrap.min.css')}}>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
  <div class="container">
    <div class="row">
        <div class="col-md-12 mt-2">
            <h4 class="text-center fw-bold ">Login Here </h4>
        </div>
    </div>
         <div class="row">
            
            <div class="col-md-4  p-3">
            @if(Session::has('wrongemail'))
                    <div class="alert alert-danger">
                        {{Session::get('wrongemail')}}
                    </div>
                @endif
                @if(Session::has('wrongpassword'))
                    <div class="alert alert-danger">
                        {{Session::get('wrongpassword')}}
                    </div>
                @endif
                  <form action="{{route('loginuser')}}" method="post">
                    @csrf
                    
                      
                      <div class="form-group">
                        <label for="" class="fw-bold m-1">Email</label>
                        <input type="text" placeholder="enter email" name="email" class="form-control">
                        @error('email') <p class="text-danger  m-0 p-0">{{$message}}</p> @enderror
                      </div>
                      <div class="form-group">
                        <label for="" class="fw-bold m-1">Password</label>
                        <input type="password" placeholder="enter password" name="password" class="form-control">
                        @error('password') <p class="text-danger  m-0 p-0">{{$message}}</p> @enderror
                      </div>
                      <div class="form-group">
                       
                        <input type="submit" value="Login" class="btn btn-primary m-2">
                        <span> Dont have account ?<a href="{{route('register')}}"> Register</a></span>
                      </div>
                  </form>
            </div>
         </div>
  </div>
</body>
</html>