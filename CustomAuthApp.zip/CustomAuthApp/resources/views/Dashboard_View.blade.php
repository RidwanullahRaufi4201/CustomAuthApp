<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href={{asset('assets/css/bootstrap.min.css')}}>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
  <div class="container">
    <div class="row">
        <div class="col-md-12 mt-2">
          
            @if(!empty($username))
            <h4 class="text-center fw-bold ">welcome {{$username}} </h4>
            @endif
        </div>
    </div>
         <div class="row">
            
            <div class="col-md-4  p-3">
           
                 <div class="alert alert-success">Dashboard</div>
                 <a href="{{route('logout')}}" class="btn btn-primary">Logout</a>
            </div>
         </div>
  </div>
</body>
</html>