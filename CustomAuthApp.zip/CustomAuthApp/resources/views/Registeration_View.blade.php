<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href={{asset('assets/css/bootstrap.min.css')}}>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
  <div class="container">
    <div class="row">
        <div class="col-md-12 mt-2">
            <h4 class="text-center fw-bold ">Register Here </h4>
        </div>
    </div>
         <div class="row">
            
            <div class="col-md-4  p-3">
            @if(Session::has('registered'))
                <div class="alert alert-success">{{Session::get('registered')}}</div>
             @endif
             @if(Session::has('notregistered'))
                <div class="alert alert-danger">
                  {{Session::get('notregistered')}}
                </div>
             @endif
                  <form action="{{route('registeruser')}}" method="post">
                    @csrf
                      <div class="form-group">
                        <label for="" class="fw-bold m-1">FirstName</label>
                        <input type="text" placeholder="enter first name" name="firstname" class="form-control">
                        @error('firstname') <p class="text-danger m-0 p-0">{{$message}}</p> @enderror
                      </div>
                      <div class="form-group">
                        <label for="" class="fw-bold m-1">LastName</label>
                        <input type="text" placeholder="enter Last name" name="lastname" class="form-control">
                        @error('lastname') <p class="text-danger  m-0 p-0">{{$message}}</p> @enderror
                      </div>
                      <div class="form-group">
                        <label for="" class="fw-bold m-1">Username</label>
                        <input type="text" placeholder="enter User name" name="username" class="form-control">
                        @error('username') <p class="text-danger  m-0 p-0">{{$message}}</p> @enderror
                      </div>
                      <div class="form-group">
                        <label for="" class="fw-bold m-1">Email</label>
                        <input type="text" placeholder="enter email" name="email" class="form-control">
                        @error('email') <p class="text-danger  m-0 p-0">{{$message}}</p> @enderror
                      </div>
                      <div class="form-group">
                        <label for="" class="fw-bold m-1">Password</label>
                        <input type="password" placeholder="enter password" name="password" class="form-control">
                        @error('password') <p class="text-danger  m-0 p-0">{{$message}}</p> @enderror
                      </div>
                      <div class="form-group">
                       
                        <input type="submit" value="Regiser" class="btn btn-primary m-2">
                       <span> Already Registered ?<a href="{{route('login')}}"> Login</a></span>
                      </div>
                  </form>
            </div>
         </div>
  </div>
</body>
</html>