<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomAuthController;



Route::get('register',[CustomAuthController::class,'Registeration_View'])->name('register');
Route::post('registeruser',[CustomAuthController::class,'Register_User'])->name('registeruser');


Route::get('/',[CustomAuthController::class,'Login_View'])->name('login');
Route::post('loginuser',[CustomAuthController::class,'Login_User'])->name('loginuser');



Route::get('dashboard',[CustomAuthController::class,'Dashboard_View'])->name('dashboard');

Route::get('Logout',[CustomAuthController::class,'Logout'])->name('logout');