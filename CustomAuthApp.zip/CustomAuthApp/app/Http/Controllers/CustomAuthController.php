<?php

namespace App\Http\Controllers;

use Illuminate\View\View;
use  Illuminate\Http\RedirectResponse;
use App\Models\User;

use Illuminate\Http\Request;
use Hash;
use Session;



class CustomAuthController extends Controller
{
    public function Registeration_View():View|RedirectResponse
    {
         if(!Session::has('loginid'))
         {
           return view('Registeration_View');
         }else
         {
            return redirect(route('dashboard'));
         }
    }


    public function Register_User(Request $request):RedirectResponse
    {
          $request->validate([
               'firstname'=>['required','min:3'],
               'lastname'=>['required','min:3'],
               'username'=>['required','min:6'],
               'email'=>['required','email','unique:users'],
               'password'=>['required','min:6'],  
          ]);

          $user=new User;
          $user->firstname=$request->firstname;
          $user->lastname=$request->lastname;
          $user->username=$request->username;
          $user->email=$request->email;
          $user->password=Hash::make($request->password);
          if($user->save())
          {
            return redirect()->back()->with('registered','Registered Successfully !');
          }else{
            return redirect()->back()->with('notregistered','Registered Unsuccessfully !');
          }


    }


    public function Login_View():View|RedirectResponse
    {
          if(!Session::has('loginid')){
              return view('Login_View');
          }
          else
          {
             return redirect(route('dashboard'));
          }
    }

    public function Login_User(Request $req)
    {
        $req->validate([
            'email'=>['required','email'],
            'password'=>['required','min:6'],  
       ]);
      
        $user=User::where('email',$req->email)->first();
        if($user)
        {
              
               if(hash::check($req->password,$user->password))
               {
                    $req->session()->put('loginid',$user->id);
                     return redirect(route('dashboard'));
               }else{
                 return redirect()->back()->with('wrongpassword','Password does not match');
               }

        }else{
            return redirect()->back()->with('wrongemail','Email does not match');
        }

    }



    public function Dashboard_View()
    {
        if(Session::has('loginid'))
        {
            $user=User::where('id','=',Session::get('loginid'))->first();
            $username=$user->username;
            return view('Dashboard_View',compact('username'));   
        }else
        {
            return redirect(route('login'));
        }
       
    }


    public function Logout()
    {
          if(Session::has('loginid'))
          {
            Session::pull('loginid');
            return redirect(route('login'));
          }else
          {
            return redirect(route('login'));
          }
    }


    
}
