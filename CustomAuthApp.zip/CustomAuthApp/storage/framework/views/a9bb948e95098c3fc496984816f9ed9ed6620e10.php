<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href=<?php echo e(asset('assets/css/bootstrap.min.css')); ?>>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
  <div class="container">
    <div class="row">
        <div class="col-md-12 mt-2">
            <h4 class="text-center fw-bold ">Register Here </h4>
        </div>
    </div>
         <div class="row">
            
            <div class="col-md-4  p-3">
            <?php if(Session::has('registered')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('registered')); ?></div>
             <?php endif; ?>
             <?php if(Session::has('notregistered')): ?>
                <div class="alert alert-danger">
                  <?php echo e(Session::get('notregistered')); ?>

                </div>
             <?php endif; ?>
                  <form action="<?php echo e(route('registeruser')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label for="" class="fw-bold m-1">FirstName</label>
                        <input type="text" placeholder="enter first name" name="firstname" class="form-control">
                        <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger m-0 p-0"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      <div class="form-group">
                        <label for="" class="fw-bold m-1">LastName</label>
                        <input type="text" placeholder="enter Last name" name="lastname" class="form-control">
                        <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger  m-0 p-0"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      <div class="form-group">
                        <label for="" class="fw-bold m-1">Username</label>
                        <input type="text" placeholder="enter User name" name="username" class="form-control">
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger  m-0 p-0"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      <div class="form-group">
                        <label for="" class="fw-bold m-1">Email</label>
                        <input type="text" placeholder="enter email" name="email" class="form-control">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger  m-0 p-0"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      <div class="form-group">
                        <label for="" class="fw-bold m-1">Password</label>
                        <input type="password" placeholder="enter password" name="password" class="form-control">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger  m-0 p-0"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      <div class="form-group">
                       
                        <input type="submit" value="Regiser" class="btn btn-primary m-2">
                       <span> Already Registered ?<a href="<?php echo e(route('login')); ?>"> Login</a></span>
                      </div>
                  </form>
            </div>
         </div>
  </div>
</body>
</html><?php /**PATH C:\Users\Ridwanullah Raufi\Desktop\LaravelPractice\lvproject07\resources\views/Registeration_View.blade.php ENDPATH**/ ?>