<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href=<?php echo e(asset('assets/css/bootstrap.min.css')); ?>>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
  <div class="container">
    <div class="row">
        <div class="col-md-12 mt-2">
          
            <?php if(!empty($username)): ?>
            <h4 class="text-center fw-bold ">welcome <?php echo e($username); ?> </h4>
            <?php endif; ?>
        </div>
    </div>
         <div class="row">
            
            <div class="col-md-4  p-3">
           
                 <div class="alert alert-success">Dashboard</div>
                 <a href="<?php echo e(route('logout')); ?>" class="btn btn-primary">Logout</a>
            </div>
         </div>
  </div>
</body>
</html><?php /**PATH C:\Users\Ridwanullah Raufi\Desktop\LaravelPractice\lvproject07\resources\views/Dashboard_View.blade.php ENDPATH**/ ?>